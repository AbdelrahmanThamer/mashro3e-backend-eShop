<?php defined('BASEPATH') or exit('No direct script access allowed');
class Webhook extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function razorpay()
    {
        //Debug in server first
        $request = file_get_contents('php://input');
        $request = json_decode($request, true);

        log_message('error', 'Razorpay IPN POST --> ' . var_export($request, true));
        $settings = get_settings('payment_method', true);
        $key = $settings['refund_webhook_secret_key'];
        if ($request['event'] == "refund.processed") {
            //Refund Successfully
            $transaction = fetch_details('transactions', ['txn_id' => $request['payload']['refund']['entity']['payment_id']]);
            if (empty($transaction)) {
                return false;
            }
            process_refund($transaction[0]['id'], $transaction[0]['status']);
        } elseif ($request['event'] == "refund.failed") {
            die("payment Failed");
        }
        die("IPN OK");
    }

    public function flutterwave()
    {
        //Debug in server first
        $request = file_get_contents('php://input');
        $request = json_decode($request, true);
    }
}
